from django.apps import AppConfig


class LedgerConfig(AppConfig):
    name = 'ledger'
